# DevOps-Tasks

# 📦 Task #1

## 📄 What the Script Does

This Python script automates the following tasks:

### ✅ Step 1: Download ZIPs of All Branches
- For every repository under a given GitHub user/org, the script downloads ZIP files for **all branches**.

### ✅ Step 2: Upload ZIPs to Google Drive
- All ZIPs are uploaded to a **Google Drive folder** using `pydrive`.

### ✅ Step 3: Intelligent Re-Download with Checksum Detection
- Before downloading, it checks if a ZIP file for a `repository-branch` combo has **changed** (based on SHA256 checksum).
- Downloads and uploads only if there is a change.

### ✅ Step 4: Google Drive Upload (Final)
- Only the ZIPs with **changed content** are uploaded to your specified Google Drive folder.

> ℹ️ This script is intended to run **daily via cron or automation** for optimal performance.

---
## 🔐 Google Drive Setup (PyDrive Auth)
* Go to Google Cloud Console.
* Create a project > Enable Google Drive API.
* Create OAuth 2.0 credentials.
* Download client_secrets.json and place it in the project directory.
* Add test users in OAuth consent screen and add your mail account otherwise it will give error.
* The first time you run the script, a browser will open to authenticate and save credentials.json.
---
## 📂 What the Scripts Do
### ✅ task1.py
* Fetches all repositories and their branches for a given GitHub username.
* Downloads each repository branch as a ZIP file into the downloaded_zips/ folder.
* Can be scheduled to run daily to keep local copies updated.
* Uses GitHub Personal Access Token (PAT) to authenticate API requests and bypass rate limiting.

### ✅ task1.1.py
* Calculates SHA256 checksums of downloaded zip files.
* Only uploads files to Google Drive if they have changed since the last run.
* Saves current checksums in checksums.json.
* Connects to Google Drive using OAuth 2.0 with PyDrive:
    - Uses client_secrets.json to initiate the authentication.
    - On first run, prompts for Google login in a browser window.
    - After successful login, creates a persistent credentials.json file for future use.
---
## 📦 Output
<img width="1919" height="1079" alt="image" src="https://github.com/user-attachments/assets/c695d4c5-4227-416e-b63d-ad297254e2b1" />
<img width="1919" height="1079" alt="image" src="https://github.com/user-attachments/assets/41ba2281-8c9f-4c4b-8e7f-30bf8d4402e1" />