import requests
import os

GITHUB_USERNAME = "Ayushgittt"
GITHUB_TOKEN = "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"  

ZIP_FOLDER = "downloaded_zips"
os.makedirs(ZIP_FOLDER, exist_ok=True)


def get_headers():
    return {
        "Authorization": f"token {GITHUB_TOKEN}"
    }

def get_repositories(username):
    url = f"https://api.github.com/users/{username}/repos"
    response = requests.get(url, headers=get_headers())
    if response.status_code == 200:
        repo_list = [repo["name"] for repo in response.json()]
        return repo_list
    else:
        print("Failed to fetch repositories.")
        print("Status:", response.status_code)
        print("Response:", response.text)
        return []
    
def get_branches(repo_name):
    url = f"https://api.github.com/repos/{GITHUB_USERNAME}/{repo_name}/branches"
    response = requests.get(url, headers=get_headers())
    if response.status_code == 200:
        return [branch["name"] for branch in response.json()]
    else:
        print(f"Failed to fetch branches for {repo_name}.")
        return []
    
def download_zip(repo, branch):
    zip_url = f"https://github.com/{GITHUB_USERNAME}/{repo}/archive/refs/heads/{branch}.zip"
    zip_path = os.path.join(ZIP_FOLDER, f"{repo}-{branch}.zip")
    
    response = requests.get(zip_url)
    if response.status_code == 200:
        with open(zip_path, "wb") as f:
            f.write(response.content)
        print(f"Downloaded {zip_path}")
    else:
        print(f"Failed to download zip for {repo} - {branch}")

def main():
    repos = get_repositories(GITHUB_USERNAME)
    latest_repos = repos[17:24]  

    for repo in latest_repos:
        print(f"\n📦 Repository: {repo}")
        branches = get_branches(repo)
        for branch in branches:
            download_zip(repo, branch)


if __name__ == '__main__':
    main()
