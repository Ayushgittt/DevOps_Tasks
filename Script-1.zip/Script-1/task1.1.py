import os
import hashlib
import json
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive

ZIP_FOLDER = "downloaded_zips"
CHECKSUM_FILE = "checksums.json"

def authenticate():
    gauth = GoogleAuth()
    gauth.LocalWebserverAuth()  # this will open browser window for first time login
    return GoogleDrive(gauth)

def calculate_checksum(file_path):
    sha256 = hashlib.sha256()
    with open(file_path, "rb") as f:
        while chunk := f.read(8192):
            sha256.update(chunk)
    return sha256.hexdigest()

def load_previous_checksums():
    if os.path.exists(CHECKSUM_FILE):
        with open(CHECKSUM_FILE, "r") as f:
            return json.load(f)
    return {}

def save_checksums(checksums):
    with open(CHECKSUM_FILE, "w") as f:
        json.dump(checksums, f, indent=2)

def upload_if_changed(drive):
    previous_checksums = load_previous_checksums()
    new_checksums = {}

    for filename in os.listdir(ZIP_FOLDER):
        if filename.endswith(".zip"):
            file_path = os.path.join(ZIP_FOLDER, filename)
            checksum = calculate_checksum(file_path)

            if previous_checksums.get(filename) != checksum:
                print(f"Change detected in: {filename}")

                # this will check for existing file
                file_list = drive.ListFile({'q': f"title='{filename}' and trashed=false"}).GetList()

                if file_list:
                    gfile = file_list[0]
                    print(f"Updating existing file: {filename}")
                else:
                    gfile = drive.CreateFile({'title': filename})
                    print(f"Uploading new file: {filename}")

                gfile.SetContentFile(file_path)
                gfile.Upload()
                print(f"Uploaded: {filename}")
            else:
                print(f"No change: {filename}")

            new_checksums[filename] = checksum

    save_checksums(new_checksums)

def main():
    drive = authenticate()
    upload_if_changed(drive)

if __name__ == "__main__":
    main()