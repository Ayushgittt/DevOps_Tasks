# DevOps-Tasks

# 📊 Task #2

## 📄 What the Script Does

This Python script analyzes **code contribution data (lines of code added, removed, or updated)** for a public GitHub repository.

### ✅ Features:
- Fetches contributor activity using the GitHub API.
- Aggregates **weekly line changes** (added, deleted, total) for each contributor.
- Filters data from **01-Jan-2023** to the **current date**.
- Displays contributions **per week per contributor**.

> ⚠️ **Note:** GitHub's API may take **a few minutes** to generate and return statistics for large or inactive repositories. Please be patient after execution.

---
## 📦 Output
Here's output of one of my repository
<img width="757" height="321" alt="image" src="https://github.com/user-attachments/assets/e77a138a-9801-42df-9af9-06e3a4e14eec" />