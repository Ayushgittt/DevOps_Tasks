import requests
import datetime


GITHUB_REPO = "Ayushgittt/Main-Project2_internship-"
START_DATE = datetime.datetime(2023, 1, 1)

def get_contributor_stats(repo):
    url = f"https://api.github.com/repos/{repo}/stats/contributors"
    response = requests.get(url)
    
    if response.status_code != 200:
        print("Error:", response.status_code, response.text)
        return []

    return response.json()

def print_weekly_contributions(stats):
    print(f"\nWeekly Contributions Since {START_DATE.date()}\n")
    
    for contributor in stats:
        if 'author' not in contributor or not contributor['author']:
            continue

        author = contributor['author']['login']
        print(f"Contributor: {author}")
        
        for week in contributor['weeks']:
            week_start = datetime.datetime.fromtimestamp(week['w'])
            if week_start >= START_DATE:
                print(f"Week of {week_start.date()}: +{week['a']} | -{week['d']} | commits: {week['c']}")
        print("-" * 40)

def main():
    stats = get_contributor_stats(GITHUB_REPO)
    if stats:
        print_weekly_contributions(stats)
    else:
        print("No data to show, wait for few min for github to fetch data.")

if __name__ == "__main__":
    main()
