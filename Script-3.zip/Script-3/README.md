# DevOps-Tasks

# 🚀 Task #3

## 📄 What the Script Does

This Python script analyzes a Linux system's SSH log file (typically `/var/log/auth.log`) and performs the following:

1. ✅ **Extracts successful SSH login attempts** using public key authentication.
   - Captures: **Username**, **IP Address**, **Port**, and **Timestamp**.
2. ✅ **Identifies failed login attempts** due to **key mismatch** (invalid or unaccepted public keys).
3. ✅ Outputs all collected entries into a CSV file named `ssh_logins.csv`.

> ℹ️ **Note:** In the provided `auth.log`, there were no actual "key mismatch" logs. Therefore, for demonstration and testing purposes, i insert one **rejected key entry** to verify the script works as expected.

---