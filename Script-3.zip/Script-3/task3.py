import re
import csv

# Input and output file
log_file = "auth.log"
output_csv = "ssh_logins.csv"


success_pattern = re.compile(
    r"^(?P<timestamp>\w{3} +\d+ \d{2}:\d{2}:\d{2}).*sshd.*Accepted publickey for (?P<user>\w+) from (?P<ip>[0-9.]+) port (?P<port>\d+)"
)

fail_pattern = re.compile(
    r"^(?P<timestamp>\w{3} +\d+ \d{2}:\d{2}:\d{2}).*sshd.*Failed publickey for (?P<user>\w+) from (?P<ip>[0-9.]+) port (?P<port>\d+)"
)

entries = []

with open(log_file, "r") as file:
    for line in file:
        match_success = success_pattern.search(line)
        match_fail = fail_pattern.search(line)

        if match_success:
            entry = match_success.groupdict()
            entry["status"] = "Success"
            entries.append(entry)

        elif match_fail:
            entry = match_fail.groupdict()
            entry["status"] = "Key Mismatch"
            entries.append(entry)


with open(output_csv, "w", newline="") as csvfile:
    fieldnames = ["timestamp", "user", "ip", "port", "status"]
    writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
    writer.writeheader()
    for row in entries:
        writer.writerow(row)

print(f"Saved {len(entries)} SSH log entries to {output_csv}")